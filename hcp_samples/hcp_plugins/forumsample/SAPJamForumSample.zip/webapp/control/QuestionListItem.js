sap.ui.define([
	"sap/jam/samples/forums/control/ForumListItem",
	"sap/jam/samples/forums/formatter/ForumFormatter"
], function(ForumListItem, ForumFormatter) {
	"use strict";

	return ForumListItem.extend("sap.jam.samples.forums.control.QuestionListItem", {
		ENTITY_NAME: "Question",

		init: function() {
			ForumListItem.prototype.init.call(this);

			this.addIconCell("sap-icon://sys-help");
			var oStatus = new sap.m.ObjectStatus({
				text: {
					path: "JamOData>Question/HasBestAnswer",
					formatter: ForumFormatter.questionStatus
				},
				state: {
					path: "JamOData>Question/HasBestAnswer",
					formatter: ForumFormatter.questionState
				}
			});
			this.addTitleCell(oStatus);
			this.addCell(new sap.m.Text({
				text: {
					path: "JamOData>Question/LastActivity",
					type: new sap.ui.model.type.DateTime({
						pattern: "MMMM d, yyyy, HH:mm:ss"
					})
				}
			}));
			this.addCell(new sap.m.Text({
				text: "{JamOData>Question/AnswersCount}"
			}));
			this.addCell(new sap.m.Text({
				text: "{JamOData>Question/LikesCount}"
			}));
		},

		renderer: {}
	});
});