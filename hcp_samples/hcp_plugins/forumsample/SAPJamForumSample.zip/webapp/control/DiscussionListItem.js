sap.ui.define([
	"sap/jam/samples/forums/control/ForumListItem"
], function(ForumListItem) {
	"use strict";

	return ForumListItem.extend("sap.jam.samples.forums.control.DiscussionListItem", {
		ENTITY_NAME: "Discussion",

		init: function() {
			ForumListItem.prototype.init.call(this);

			this.addIconCell("sap-icon://discussion");
			this.addTitleCell();
			this.addCell(new sap.m.Text({
				text: {
					path: "JamOData>Discussion/LastActivity",
					type: new sap.ui.model.type.DateTime({
						pattern: "MMMM d, yyyy, HH:mm:ss"
					})
				}
			}));
			this.addCell(new sap.m.Text({
				text: ""
			}));
			this.addCell(new sap.m.Text({
				text: ""
			}));
		},

		renderer: {}
	});
});