sap.ui.define([
	"sap/m/ColumnListItem",
	"sap/jam/samples/forums/formatter/ForumFormatter"
], function(ColumnListItem, ForumFormatter) {
	"use strict";

	return ColumnListItem.extend("sap.jam.samples.forums.control.ForumListItem", {
		BINDING_URL: "",

		init: function() {
			ColumnListItem.prototype.init.call(this);
		},

		addIconCell: function(sUrl) {
			this.addCell(new sap.ui.core.Icon({
				src: sUrl
			}));
		},

		addTitleCell: function(oStatus) {
			var self = this;

			var oTitle = new sap.m.ObjectHeader({
				title: {
					path: "JamOData>" + this.ENTITY_NAME + "/Name",
					formatter: ForumFormatter.truncate
				},
				titleActive: true,
				titlePress: function() {
					if (self.ENTITY_NAME) {
						var bus = sap.ui.getCore().getEventBus();
						bus.publish("nav", "to", {
							id: self.ENTITY_NAME,
							data: {
								context: self.getBindingContext("JamOData")
							}
						});
					}
				},
				attributes: [
					new sap.m.ObjectAttribute({
						text: {
							path: "JamOData>" + this.ENTITY_NAME + "/Content",
							formatter: ForumFormatter.stripAndTruncateHtml
						},
						visible: {
							path: "JamOData>" + this.ENTITY_NAME + "/Content",
							formatter: function(sVal) {
								return !!(sVal && sVal.length > 0);
							}
						}
					})
				]
			});
			if (oStatus) {
				oTitle.addStatus(oStatus);
			}

			var oCreatorText = new sap.m.ObjectAttribute({
				text: "{JamOData>Creator/FullName}"
			});
			oCreatorText.bindElement(this.ENTITY_NAME, {
				expand: "Creator"
			});
			oTitle.addAttribute(oCreatorText);
			oTitle.addStyleClass("forum_list_item");

			this.addCell(oTitle);
		},

		renderer: {}
	});
});