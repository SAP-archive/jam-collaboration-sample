sap.ui.define([
	"sap/jam/samples/forums/control/ForumListItem",
	"sap/jam/samples/forums/formatter/ForumFormatter"
], function(ForumListItem, ForumFormatter) {
	"use strict";

	return ForumListItem.extend("sap.jam.samples.forums.control.IdeaListItem", {
		ENTITY_NAME: "Idea",

		init: function() {
			ForumListItem.prototype.init.call(this);
			this.addIconCell("sap-icon://lightbulb");
			var oStatus = new sap.m.ObjectStatus({
				text: {
					path: "JamOData>Idea/Status",
					formatter: ForumFormatter.ideaStatus
				},
				state: {
					path: "JamOData>Idea/Status",
					formatter: ForumFormatter.ideaState
				}
			});
			this.addTitleCell(oStatus);
			this.addCell(new sap.m.Text({
				text: {
					path: "JamOData>Idea/LastActivity",
					type: new sap.ui.model.type.DateTime({
						pattern: "MMMM d, yyyy, HH:mm:ss"
					})
				}
			}));
			this.addCell(new sap.m.Text({
				text: ""
			}));
			this.addCell(new sap.m.Text({
				text: "{JamOData>Idea/TotalVotes}"
			}));
		},

		renderer: {}
	});
});