sap.ui.define([], function() {
	"use strict";
	return {
		parseErrorMessage: function(oError) {
			var title = oError.message,
				resp,
				statusCode,
				message;
			try {
				if (oError.getParameter) {
					title = oError.getParameter("message");
					statusCode = oError.getParameter("statusCode");
					resp = JSON.parse(oError.getParameter("responseText"));
				} else if (oError.response) {
					resp = JSON.parse(oError.response.body);
				}
			} catch (e) {
				// JSON didn't parse correctly, so ignore it.
			}
			if (!statusCode) {
				statusCode = (oError && oError.response && oError.response.statusCode) ? oError.response.statusCode : undefined;
				statusCode = statusCode || ((oError && oError.status) ? oError.status : undefined);
			}
			if (resp && resp["error"] && resp["error"]["message"] && resp["error"]["message"]["value"]) {
				message = resp["error"]["message"]["value"];
			} else {
				message = "Unknown error";
			}

			return [message, title];
		}
	};
});