sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/ODataModel"
], function(Controller, ODataModel) {
	"use strict";

	return Controller.extend("sap.jam.samples.forums.controller.ForumWidget", {
		onInit: function() {
			this.setModel(new ODataModel("/destinations/sapjam_developer", true), "JamOData");

			var bus = sap.ui.getCore().getEventBus();
			bus.subscribe("nav", "to", this.navToHandler, this);
			bus.subscribe("nav", "back", this.navBackHandler, this);
		},

		getModel: function(sName) {
			return this.getView().getModel(sName) || this.getOwnerComponent().getModel(sName);
		},

		setModel: function(oModel, sName) {
			oModel.setDefaultCountMode(sap.ui.model.odata.CountMode.None);
			return this.getView().setModel(oModel, sName);
		},

		navToHandler: function(channelId, eventId, data) {
			var oApp = this.byId("ForumApp");
			if (data && data.id) {
				// if (oApp.getPage(data.id) === null) {
				// 	oApp.addPage(sap.ui.jsview(data.id, "sap.jam." + data.id));
				// }
				oApp.to(this.createId(data.id), data.data.context);
			} else {
				jQuery.sap.job.error("Navigation failed. Invalid data: " + data);
			}
		},

		groupChanged: function(evt) {
			this.byId("ForumList").destroyContent();
			var oView = new sap.ui.view({
				viewName: "sap.jam.samples.forums.view.ForumList",
				type: sap.ui.core.mvc.ViewType.XML
			});
			this.byId("ForumList").addContent(oView);
			oView.bindElement("JamOData>/" + evt.getParameters().selectedItem.getKey());
		},

		navBackHandler: function() {
			this.byId("ForumApp").back();
		},

		onBeforeRendering: function() {},

		onAfterRendering: function() {}

	});

});