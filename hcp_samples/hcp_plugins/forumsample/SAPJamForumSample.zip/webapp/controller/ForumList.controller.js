sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/jam/samples/forums/control/QuestionListItem",
	"sap/jam/samples/forums/control/DiscussionListItem",
	"sap/jam/samples/forums/control/IdeaListItem"
], function(Controller, QuestionListItem, DiscussionListItem, IdeaListItem) {
	"use strict";

	return Controller.extend("sap.jam.samples.forums.controller.ForumList", {

		onInit: function() {
			var bus = sap.ui.getCore().getEventBus();
			bus.subscribe("nav", "back", this.navBackHandler, this);
		},

		refreshList: function() {
			this.getModel("JamOData").refresh();
		},

		navBackHandler: function() {
			//re-bind active forum table, model refresh makes it lose data for some reason
			var oContainer = this.getView().getContent()[0];
			this.bindTable(oContainer.getCurrentDetailPage());
		},

		navAction: function(evt) {
			var self = this;
			var oContainer = this.getView().getContent()[0];
			oContainer.getDetailPages().forEach(function(page) {
				if (page.getTitle() === evt.getSource().getText()) {
					self.bindTable(page);
					oContainer.toDetail(page.getId());
					oContainer.hideMaster();
				}
			});
		},

		getForumTemplate: function(sId, oContext) {
			var type = oContext.getProperty("ForumItemType");
			switch (type) {
				case "Question":
					var oQuestionTemplate = new QuestionListItem();
					return oQuestionTemplate;
				case "Idea":
					var oIdeaTemplate = new IdeaListItem();
					return oIdeaTemplate;
				case "Discussion":
					var oDiscussionTemplate = new DiscussionListItem();
					return oDiscussionTemplate;
			}
		},

		bindTable: function(oPage) {
			var oTable = oPage.getContent()[0];
			if (oTable) {
				oTable.bindAggregation("items", {
					path: "JamOData>ForumItems",
					factory: this.getForumTemplate,
					parameters: {
						expand: "Idea,Discussion,Question"
					}
				});
			}
		}

	});

});