sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/jam/samples/forums/formatter/ForumFormatter",
	"sap/jam/samples/forums/StringHelper",
	"sap/m/MessageBox"
], function(Controller, ForumFormatter, StringHelper, MessageBox) {
	"use strict";

	return Controller.extend("sap.jam.samples.forums.controller.Idea", {
		formatter: ForumFormatter,

		onInit: function() {
			this.getView().addEventDelegate({
				onBeforeShow: function(evt) {
					this.setModel(evt.data.getModel(), "JamOData");
					this.bindElement("JamOData>Idea", {
						expand: "Creator"
					});
					this.setBindingContext(evt.data, "JamOData");
				}
			}, this.getView());

			this.initStatusItems();
		},

		backTriggered: function() {
			var bus = sap.ui.getCore().getEventBus();
			bus.publish("nav", "back");
		},

		deletePressed: function() {
			var self = this;
			MessageBox.confirm(ForumFormatter.getText("trash.confirmation.body"),
				function(oAction) {
					if (oAction !== MessageBox.Action.OK) {
						return;
					}
					self.byId("FeedList").unbindAggregation("items");
					var path = self.getView().getBindingContext("JamOData").getPath();
					var oModel = self.getView().getModel("JamOData");
					oModel.remove(path, {
						fnSuccess: function() {
							this.backTriggered();
						},
						fnError: StringHelper.showErrorMessage
					});
				},
				ForumFormatter.getText("trash.confirmation.title")
			);
		},

		textChanged: function(evt) {
			var enabled = !!evt.getParameters().newValue;
			this.byId("PostButton").setEnabled(enabled);
		},

		postButtonPressed: function(evt) {
			var oPostArea = this.byId("PostArea");
			var postBody = {
				Comment: oPostArea.getValue()
			};
			var context = this.getView().getBindingContext("JamOData");
			var oModel = this.getView().getModel("JamOData");
			oModel.create("Posts", postBody, context, function() {
				oPostArea.setValue("");
				evt.getSource().setEnabled(false);
			}, StringHelper.showErrorMessage);
		},

		statusChanged: function(evt) {
			var oItem = evt.getParameters().selectedItem;
			var putBody = {
				Status: oItem.getKey()
			};
			var path = this.getView().getBindingContext("JamOData").getPath() + "/Status";
			var oModel = this.getView().getModel("JamOData");
			oModel.update(path, putBody, {
				fnSuccess: function() {},
				fnError: StringHelper.showErrorMessage
			});
		},

		STATUS_KEYS: ["submitted", "under_consideration", "in_progress", "accepted", "declined", "completed"],
		initStatusItems: function() {
			var oSelect = this.byId("StatusSelect");
			oSelect.destroyItems();
			this.STATUS_KEYS.forEach(function(sKey) {
				oSelect.addItem(new sap.ui.core.Item({
					key: sKey,
					text: ForumFormatter.ideaStatus(sKey)
				}));
			});
		},

		voteUp: function() {
			var oControl = this.byId("UpLabel");
			this.putVote("Up", oControl);
		},

		voteDown: function() {
			var oControl = this.byId("DownLabel");
			this.putVote("Down", oControl);
		},

		putVote: function(sValue, oControl) {
			var putBody = {
				Vote: sValue
			};
			var path = this.getView().getBindingContext("JamOData").getPath() + "/Vote";
			var oModel = this.getView().getModel("JamOData");
			oModel.update(path, putBody, {
				fnSuccess: function() {
					var val = parseInt(oControl.getText());
					oControl.setText(val + 1);
				},
				fnError: StringHelper.showErrorMessage
			});
		}

	});

});