sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/jam/samples/forums/formatter/ForumFormatter",
	"sap/jam/samples/forums/StringHelper",
	"sap/m/MessageBox"
], function(Controller, ForumFormatter, StringHelper, MessageBox) {
	"use strict";

	return Controller.extend("sap.jam.samples.forums.controller.Question", {
		formatter: ForumFormatter,

		onInit: function() {
			var bus = sap.ui.getCore().getEventBus();
			bus.subscribe("question", "mark_best_answer", this.markBestAnswerHandler, this);

			this.getView().addEventDelegate({
				onBeforeShow: function(evt) {
					this.setModel(evt.data.getModel(), "JamOData");
					this.bindElement("JamOData>Question", {
						expand: "Creator,BestAnswer"
					});
					this.setBindingContext(evt.data, "JamOData");

					//this.bindAnswerFeed(oFeedList);
				}
			}, this.getView());

			this.byId("AnswerButton").setLayoutData(new sap.m.FlexItemData({
				alignSelf: sap.m.FlexAlignSelf.End
			}));
		},

		backTriggered: function() {
			var bus = sap.ui.getCore().getEventBus();
			bus.publish("nav", "back");
		},

		markBestAnswer: function(evt) {
			var self = this;
			var uri = evt.getSource().getBindingContext("JamOData").getProperty("__metadata/uri");
			var id = evt.getSource().getBindingContext("JamOData").getProperty("Id");
			var postData = {
				uri: uri
			};
			var path = "$links/BestAnswer";
			var oModel = this.getView().getModel("JamOData");
			oModel.create(path, postData, this.getView().getBindingContext("JamOData"),
				function() {
					self.bestAnswerId = id;
					self.byId("FeedList").getItems().forEach(function(oItem) {
						var sId = oItem.getBindingContext("JamOData").getProperty("Id");
						oItem.getContent()[0].setInfo(self.getIsBestAnswer(sId));
					});
				},
				function() {
					MessageBox.alert("Mark best answer failed");
				}
			);
		},

		likePressed: function(evt) {
			var liked = evt.getSource().getText() === ForumFormatter.getText("common.like");
			var putBody = {
				Liked: liked
			};
			var path = this.getView().getBindingContext("JamOData").getPath() + "/Liked";
			var oModel = this.getView().getModel("JamOData");
			oModel.update(path, putBody, {
				fnSuccess: function() {
					oModel.setProperty(path, liked);
				},
				fnError: StringHelper.showErrorMessage
			});
		},

		deletePressed: function() {
			var self = this;
			MessageBox.confirm(ForumFormatter.getText("trash.confirmation.body"),
				function(oAction) {
					if (oAction !== MessageBox.Action.OK) {
						return;
					}
					self.byId("FeedList").unbindAggregation("items");
					var path = self.getView().getBindingContext("JamOData").getPath();
					var oModel = self.getView().getModel("JamOData");
					oModel.remove(path, {
						fnSuccess: function() {
							this.backTriggered();
						},
						fnError: StringHelper.showErrorMessage
					});
				},
				ForumFormatter.getText("trash.confirmation.title")
			);
		},

		textChanged: function(evt) {
			var enabled = !!evt.getParameters().newValue;
			this.byId("AnswerButton").setEnabled(enabled);
		},

		answerButtonPressed: function(evt) {
			var oAnswerArea = this.byId("AnswerArea");
			var postBody = {
				Comment: oAnswerArea.getValue()
			};
			var context = this.getView().getBindingContext("JamOData");
			var oModel = this.getView().getModel("JamOData");
			oModel.create("Answers", postBody, context, function() {
				oAnswerArea.setValue("");
				evt.getSource().setEnabled(false);
			}, StringHelper.showErrorMessage);
		},

		getBestAnswerId: function() {
			if (!this.bestAnswerId) {
				this.bestAnswerId = this.getView().getBindingContext("JamOData").getProperty("BestAnswer/Id");
			}
			return this.bestAnswerId;
		},

		getIsBestAnswer: function(sId) {
			if (sId === this.getBestAnswerId()) {
				return ForumFormatter.getText("crowd_sourced.inquiry.best_answer");
			}
			return "";
		},

		onBeforeRendering: function() {
			this.bestAnswerId = null;
		}
	});

});