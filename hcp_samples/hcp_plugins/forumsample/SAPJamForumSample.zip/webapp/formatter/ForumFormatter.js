sap.ui.define([], function() {
	"use strict";
	sap.jam.ForumFormatter = {
		ideaStatus: function(sValue) {
			switch (sValue) {
				case "submitted":
					return sap.jam.ForumFormatter.getText("crowd_sourced.idea.submitted");
				case "under_consideration":
					return sap.jam.ForumFormatter.getText("crowd_sourced.idea.under_consideration");
				case "in_progress":
					return sap.jam.ForumFormatter.getText("crowd_sourced.idea.in_progress");
				case "accepted":
					return sap.jam.ForumFormatter.getText("crowd_sourced.idea.accepted");
				case "declined":
					return sap.jam.ForumFormatter.getText("crowd_sourced.idea.declined");
				case "completed":
					return sap.jam.ForumFormatter.getText("crowd_sourced.idea.completed");
				default:
					return sValue;
			}
		},

		ideaState: function(sValue) {
			switch (sValue) {
				case "under_consideration":
				case "in_progress":
					return sap.ui.core.ValueState.Warning;
				case "accepted":
				case "completed":
					return sap.ui.core.ValueState.Success;
				case "declined":
					return sap.ui.core.ValueState.Error;
				default:
					return sap.ui.core.ValueState.None;
			}
		},

		questionState: function(bValue) {
			if (bValue) {
				return sap.ui.core.ValueState.Success;
			}
			return sap.ui.core.ValueState.None;
		},

		questionStatus: function(bValue) {
			if (bValue) {
				return sap.jam.ForumFormatter.getText("crowd_sourced.inquiry.answered");
			}
			return "";
		},

		stripHtml: function(sVal) {
			var sContent = "";
			if (sVal) {
				sContent = sVal.replace(/<[^>]*>?/g, ""); //strip html
			}
			return sContent;
		},

		truncate: function(sText, length) {
			length = length || 70;
			if (sText && sText.length > length) {
				return sText.substring(0, length) + "...";
			}
			return sText;
		},

		stripAndTruncateHtml: function(sVal, length) {
			return sap.jam.ForumFormatter.truncate(sap.jam.ForumFormatter.stripHtml(sVal), length);
		},

		getText: function(sKey) {
			var oBundle = sap.jam.ForumFormatter.getBundle();
			if (oBundle) {
				return oBundle.getText(sKey);
			}
		},

		getBundle: function() {
			if (!sap.jam.ForumFormatter.oBundle) {
				var sLocale = sap.ui.getCore().getConfiguration().getLanguage();
				var resUrl = jQuery.sap.getModulePath("sap.jam.samples.forums", "/i18n/i18n.properties");
				sap.jam.ForumFormatter.oBundle = jQuery.sap.resources({
					url: resUrl,
					locale: sLocale
				});
			}
			return sap.jam.ForumFormatter.oBundle;
		},

		formatLikes: function(bLiked) {
			var key = bLiked === true ? "common.unlike" : "common.like";
			return sap.jam.ForumFormatter.getText(key);
		},

		formatHTMLContent: function(sContent) {
			return "<div>" + sContent + "</div>";
		},

		memberThumbnailFormatter: function(memberODataEntity) {
			if (!memberODataEntity) {
				return "";
			}
			return "/destinations/sapjam_developer/" + memberODataEntity + "/ThumbnailImage/$value";
		},

		getDateType: function() {
			return new sap.ui.model.type.DateTime({
				pattern: "MMMM d, yyyy, HH:mm:ss"
			});
		}

		// creatorThumbnail: function(sId) {
		// 	return sId ? sap.jam.ProxyHelper.getODataUrl("/Members('" + sId + "')/ProfilePhoto/$value", this.getModel()) : null;
		// }
	};
	return sap.jam.ForumFormatter;

});