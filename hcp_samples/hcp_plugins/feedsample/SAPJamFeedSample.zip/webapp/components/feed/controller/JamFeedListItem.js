jQuery.sap.require("sap.m.library");
jQuery.sap.require("sap.m.ListItemBase");
jQuery.sap.require("sap.m.FeedListItem");
jQuery.sap.require("sap.m.BusyIndicator");

sap.m.FeedListItem.extend("sap.jam.samples.components.feed.controller.JamFeedListItem", {
	metadata: {
		properties: {
			"feedId": "string",
			"title": "string",
			'liked': 'boolean',
			'canLike': 'boolean',
			'canComment': 'boolean',
			'creator': 'object',
			'targetTitle': 'string',
			'type': 'string',
			'odataUrl': 'string',
			'lastReply': 'object',
			'parentFeedUri': 'string'
		},

		aggregations: {
			"_footer": {
				type: "sap.m.HBox",
				multiple: false,
				visibility: "hidden"
			},
			"_comments": {
				type: "sap.m.List",
				multiple: false,
				visibility: "hidden"
			},
			"_replyBar": {
				type: "sap.m.HBox",
				multiple: false,
				visibility: "hidden"
			}
		}
	},

	init: function() {
		this.setAggregation("_comments", new sap.m.List({
			showNoData: false,
			showSeparators: sap.m.ListSeparators.None,
			growing: true,
			growingThreshold: 4,
			growingScrollToLoad: false
		}));

		this.initFooter();
		this.initReplyBox();
	},

	refreshFeeds: function() {
		var modelPath = this.getParentFeedUri();
		this.getModel("JamFeed").loadData(modelPath);

		// Scroll to top of page
		var element = document.getElementById("__xmlview1--__input0-icon");
		element.scrollIntoView();
	},

	initReplyBox: function() {
		var self = this,
			oFooter = this.__getFooterControl();

		this.oShowReplyLink = new sap.m.Link({
			icon: "sap-icon://comment",
			text: "Reply",
			press: function() {
				self.__getReplyBarControl().setVisible(true);
			}
		});

		this.oShowReplyLink.addStyleClass('feed_action_link');

		oFooter.addItem(new sap.m.Text({
			text: '•'
		}));
		oFooter.addItem(this.oShowReplyLink);

		this.oReplyInput = new sap.m.TextArea({
			width: '100%',
			height: '55px',
			layoutData: new sap.m.FlexItemData({
				growFactor: 1
			})
		});

		this.oReplyButton = new sap.m.Button({
			icon: "sap-icon://feeder-arrow"
		});

		this.oReplyCancelButton = new sap.m.Button({
			icon: "sap-icon://sys-cancel",
			press: function() {
				self.__getReplyBarControl().setVisible(false);
			}
		});

		this.setAggregation('_replyBar', new sap.m.HBox({
			justifyContent: sap.m.FlexJustifyContent.Center,
			alignItems: sap.m.FlexAlignItems.Center,
			fitContainer: true,
			items: [this.oReplyInput, this.oReplyButton, this.oReplyCancelButton],
			visible: false
		}));

		this.oReplyButton.attachPress(function(oEvent) {
			var text = self.oReplyInput.getValue();
			if (text) {
				var postBody = {
					Text: text
				};
				var oModel = self.getModel("SAPJam");

				var replyBindPath = self.getBindingContextPath();
				var replyUri = "/" + this.getModel("JamFeed").getProperty(replyBindPath + "/__metadata/uri") + "/Replies";

				oModel.create(replyUri, postBody, {
					success: function() {
						self.refreshFeeds();
					}
				});
			} else {
				sap.m.MessageBox.alert('Can not post an empty reply, please write some text to share');
			}
		});

		this.oReplyButton.addStyleClass('feed_item_link');
	},

	initFooter: function() {
		var self = this;
		var oFooter = new sap.m.HBox({
			justifyContent: sap.m.FlexJustifyContent.Start
		});
		this.setAggregation("_footer", oFooter);

		oFooter.addItem(this.oLikesText);

		this.oLikeLink = new sap.m.Link({
			text: "Like"
		});

		this.oLikeLink.attachPress(function(oEvent) {
			var likeBindPath = self.getBindingContextPath();
			var likeUri = "/" + this.getModel("JamFeed").getProperty(likeBindPath + "/__metadata/uri") + "/Liked";
			var liked = (this.getModel("JamFeed").getProperty(likeBindPath + "/Liked"));
			var putBody = {
				Liked: liked ? false : true
			};

			this.getModel("SAPJam").update(likeUri, putBody, {
				success: function() {
					self.getModel("JamFeed").setProperty(likeBindPath + "/Liked", !liked);
					self.setProperty("liked", !liked);
					var likeText = self.getLiked() ? "Like" : "UnLike";
					self.oLikeLink.setText(likeText);
				}
			});
		});

		this.oLikeLink.addStyleClass('feed_item_link');
		oFooter.addItem(this.oLikeLink);
	},

	onBeforeRendering: function() {
		var oFooter = this.__getFooterControl();

		if (!this.getCanLike()) {
			oFooter.removeItem(this.oLikeLink);
		}
		if (!this.getCanComment()) {
			oFooter.removeItem(this.oReplyButton);
		}
	},

	onAfterRendering: function() {
		var likeText = this.getLiked() ? "Unlike" : "Like";
		this.oLikeLink.setText(likeText);
	},

	__getFooterControl: function() {
		return this.getAggregation("_footer");
	},

	__getCommentListControl: function() {
		return this.getAggregation("_comments");
	},

	__getReplyBarControl: function() {
		return this.getAggregation("_replyBar");
	},

	renderer: "sap.jam.samples.components.feed.controller.JamFeedListItemRenderer"
});