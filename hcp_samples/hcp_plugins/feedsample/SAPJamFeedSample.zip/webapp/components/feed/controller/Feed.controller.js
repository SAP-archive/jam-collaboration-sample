sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/json/JSONModel",
	"sap/jam/samples/components/feed/controller/JamFeedListItem"
], function(Controller, DateFormat, JSONModel, JamFeedListItem) {
	"use strict";
	return Controller.extend("sap.jam.samples.components.feed.controller.Feed", {

		onInit: function() {
			// Attach route handlers
			this.getRouter().getRoute("memberFeed").attachPatternMatched(this.onMemberFeedMatched, this);

			// This component will use an internal JSON model rather than binding to an OData endpoint
			// TODO - make this a bit more efficient on the expanded $selects...
			this.select = "Creator,Liked,CanLike,CreatedAt,Title,ThumbnailImage,Text,ActionOnly,TargetObjectReference,LikesCount,Likers,LastReply";
			this.expand = "Creator,ThumbnailImage,TargetObjectReference,Group,LastReply,LastReply/Creator,LastReply/ThumbnailImage";
			this.format = "json";

			this.uri = "/FeedEntries?$select=" + this.select +
						"&$expand=" + this.expand + 
						"&$format=" + this.format;

			this.setModel(new JSONModel({d:{results:[]}}).setDefaultBindingMode("OneWay"), "JamFeed");
			this.setModel(new JSONModel("/destinations/sapjam_developer/Self?$select=FullName&$format=json").setDefaultBindingMode("OneWay"), "JamSelf");

			var oFeedsList = this.getView().byId("FeedsList");
			oFeedsList.bindAggregation(
				"items",
				"JamFeed>/d/results",
				this.feedListFactory.bind(this));
		},
		
		onMemberFeedMatched: function() {
			this.getModel("JamFeed").setData({d:{results:[]}});
			this.setPath("");
			this.refresh();
		},
		
		onGroupFeedMatched: function(oEvent) {
			this.getModel("JamFeed").setData({d:{results:[]}});

			var groupId = oEvent.getParameter("arguments").groupId;
			this.setPath("/Groups('" + groupId + "')");
			this.refresh();
		},

		onFeedPost: function(oEvent) {
			var postBody = {
				Text: oEvent.getSource().getValue()
			};
			var self = this;
			this.getModel("SAPJam").create(this.getPath() + "/FeedEntries", postBody, {
				success: function() {
					self.refresh();
				}
			});
		},
		
		onLoadMore: function() {
			var loadPath =  "/destinations/sapjam_developer/" + this.getModel("JamFeed").getProperty("/d").__next;
		    var self = this;

	    	jQuery.ajax({
			    url: loadPath,
			    dataType: "json",
			    success: function(data) {
					var oDataList = self.getModel("JamFeed").getData();
					for	(var i = 0; i < data.d.results.length; i++) {
						oDataList.d.results.push(data.d.results[i]);
					}

				oDataList.d.__next = data.d.__next;
				self.getModel("JamFeed").setData(oDataList);
			    self.getModel("JamFeed").refresh(true);
			    
			    var loadButton = self.getView().byId("loadButton");
		        if(oDataList.d.__next) {
		           loadButton.setVisible(true);
			      } else {
			      	loadButton.setVisible(false);
			      }
			    }
			});
		},

	    refresh: function() {
	    	var modelPath = "/destinations/sapjam_developer";
	    	if ( this.getPath() !== "" ) {
	    		modelPath += this.getPath();
	    	}
	    	modelPath += this.uri;
	    	this.getModel("JamFeed").loadData(modelPath);
	    },

		timeFormatter: function(jsonDate) {
			var utcTime = parseInt(jsonDate.substr(6));
			var date = new Date(utcTime);
			var formatter = DateFormat.getDateTimeInstance({
				style: "long",
				relative: true,
				relativeScale: "auto"
			});

			return formatter.format(date);
		},

		setPath: function(oDataPath) {
			this._path = oDataPath;
		},

		getPath: function() {
			return this._path;
		},

		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		getModel: function(sName) {
			return this.getView().getModel(sName) || this.getOwnerComponent().getModel(sName);
		},

		setModel: function(oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},
		
		feedListFactory: function(sId, oContext) {
			var oUIControl = null;
			var lastReplyData = null;

			var lastReplayContent = oContext.getProperty("LastReply");
			if (lastReplayContent) {
				lastReplyData = {
					lastModifiedAt: this.timeFormatter(lastReplayContent.LastModifiedAt),
					text: lastReplayContent.Text,
					creator: lastReplayContent.Creator.FullName,
					icon: "/destinations/sapjam_developer/" + lastReplayContent.ThumbnailImage.__metadata.media_src
				};
			}

			oUIControl = new JamFeedListItem(sId, {
				feedId: "{Id}",
				sender: oContext.getProperty("Creator").FullName,
				text: oContext.getProperty("Text"),
				title: oContext.getProperty("ActionOnly"),
				liked: oContext.getProperty("Liked"),
				timestamp: this.timeFormatter(oContext.getProperty("CreatedAt")),
				canLike: oContext.getProperty("CanLike"),
				icon: "/destinations/sapjam_developer/" + oContext.getProperty("ThumbnailImage").__metadata.media_src,
				targetTitle: oContext.getProperty("TargetObjectReference") ? oContext.getProperty("TargetObjectReference").Title : "",
				type: oContext.getProperty("TargetObjectReference") ? oContext.getProperty("TargetObjectReference").Type : "",
				odataUrl: oContext.getProperty("TargetObjectReference") ? oContext.getProperty("TargetObjectReference").ODataURL : "",
				lastReply: lastReplyData,
				parentFeedUri: "/destinations/sapjam_developer" + this.getPath() + this.uri
			});

			return oUIControl;
		}

	});
});