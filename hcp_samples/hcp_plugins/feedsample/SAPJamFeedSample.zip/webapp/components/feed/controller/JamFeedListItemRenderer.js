jQuery.sap.declare('sap.jam.samples.components.feed.controller.JamFeedListItemRenderer');
jQuery.sap.require('sap.ui.core.Renderer');
jQuery.sap.require('sap.m.ListItemBaseRenderer');
jQuery.sap.require('sap.m.FeedListItemRenderer');
jQuery.sap.require('sap.ui.commons.FormattedTextView');
jQuery.sap.require('sap.ui.core.format.DateFormat');

sap.jam.samples.components.feed.controller.JamFeedListItemRenderer = sap.ui.core.Renderer.extend(sap.m.FeedListItemRenderer);
sap.jam.samples.components.feed.controller.JamFeedListItemRenderer.formatterText = sap.ui.core.format.DateFormat.getDateTimeInstance({
	pattern: "MMMM d, yyyy, HH:mm:ss"
});
sap.jam.samples.components.feed.controller.JamFeedListItemRenderer.formatterIso8691 = sap.ui.core.format.DateFormat.getDateTimeInstance({
	pattern: "yyyy-MM-ddTHH:mm:ssZ"
});

sap.jam.samples.components.feed.controller.JamFeedListItemRenderer.renderLIIcon = function(m, rm, iconUri, styleClass) {
	rm.write('<img src=' + iconUri + ' class="sapMFeedListItemFigure sapMFeedListItemIsDefaultIcon ' + styleClass + '"/>');
};

sap.jam.samples.components.feed.controller.JamFeedListItemRenderer.renderLINameHeader = function(m, rm, name) {
	rm.write('<span id="' + m + '-name" class="sapMFeedListItemTextName">');
	rm.write(name);
	rm.write(' ');
	rm.write('</span>');
};

sap.jam.samples.components.feed.controller.JamFeedListItemRenderer.renderLIDate = function(m, rm, dateInfo) {
	rm.write('<span class="timeago" datetime="' + dateInfo + '">');
	rm.writeEscaped(dateInfo);
	rm.write('</span>');
	rm.write('<span></span>');
};

sap.jam.samples.components.feed.controller.JamFeedListItemRenderer.renderLIText = function(m, rm, oControl) {
	var sText = oControl.getText() || "";
	rm.writeEscaped(oControl.getTitle());

	if (!!oControl.getTimestamp()) {
		rm.write('<p class="sapMFeedListItemFooter">');
		var oTime = sap.jam.samples.components.feed.controller.JamFeedListItemRenderer.formatterIso8691.parse(oControl.getTimestamp());
		this.renderLIDate(m, rm, sap.jam.samples.components.feed.controller.JamFeedListItemRenderer.formatterText.format(oTime));
		rm.write('</p>');
	}

	rm.write('</br>');

	rm.write('<p class="sapMFeedListItemTextText">');
	rm.writeEscaped(sText);
	rm.write('</p>');
};

sap.jam.samples.components.feed.controller.JamFeedListItemRenderer.renderLILastReply = function(m, rm, oControl) {
	rm.write('<div class="feed_comment_content">');
	var lastReply = oControl.getLastReply();

	rm.write('<div style="margin:0px">');

	rm.write('<div class="feed_reply_icon_container">');
	this.renderLIIcon(m, rm, lastReply.icon, "feed_icon_small");
	rm.write('</div>');

	rm.write('<p id="' + m + '-text-reply" class="sapMFeedListItemTextText">');
	this.renderLINameHeader(m, rm, lastReply.creator);

	rm.writeEscaped(lastReply.text || "");

	rm.write('<p class="sapMFeedListItemFooter">');
	var oTime = sap.jam.samples.components.feed.controller.JamFeedListItemRenderer.formatterIso8691.parse(lastReply.lastModifiedAt);
	this.renderLIDate(m, rm, sap.jam.samples.components.feed.controller.JamFeedListItemRenderer.formatterText.format(oTime));
	rm.write('</p>');

	rm.write('</p>');
	rm.write('</div>');
	rm.write('</div>');
};

sap.jam.samples.components.feed.controller.JamFeedListItemRenderer.renderLIContent = function(rm, oControl) {
	var m = oControl.getId();

	rm.write('<article');
	rm.writeControlData(oControl);
	rm.addClass('sapMFeedListItem');
	rm.writeClasses();
	rm.write('>');

	this.renderLIIcon(m, rm, oControl.getIcon(), "feed_icon");
	rm.write('<div class= "sapMFeedListItemText sapMFeedListItemHasFigure" >');
	rm.write('<p id="' + m + '-text" class="sapMFeedListItemTextText">');
	if (oControl.getSender()) {
		this.renderLINameHeader(m, rm, oControl.getSender());
	}

	this.renderLIText(m, rm, oControl);

	if (oControl.getType() == "Image" || oControl.getType() == "ContentItem") {
		rm.write('<div>');
		rm.write("<img src=" + oControl.getOdataUrl() + "/$value" + " />");
		rm.write('</div>');
	}
	rm.write('</p>');
	rm.renderControl(oControl.__getFooterControl());

	if (oControl.__getCommentListControl()) {
		rm.renderControl(oControl.__getCommentListControl());
	}
	if (oControl.__getReplyBarControl()) {
		rm.renderControl(oControl.__getReplyBarControl());
	}

	if (oControl.getLastReply()) {
		this.renderLILastReply(m, rm, oControl, oControl.getLastReply());
	}

	rm.write('</div>');
	rm.write('</article>');
};