sap.ui.define([
	"sap/m/Input"
], function(Input) {
	"use strict";

	return Input.extend("sap.jam.samples.components.grouplist.MultiSuggestInput", {
	  metadata: {
	    properties: {
	      "valueTokens": "string[]"
	    }
	  },
	
	  init: function() {
	    Input.prototype.init.call(this);
	
	    var self = this;
	    this.setFilterFunction(function(sTerm, oItem) {
	      var aTokens = sTerm.trim().split(new RegExp("\\s*,\\s*"));
	      var sFilter = aTokens.pop();
	      self.setValueTokens(aTokens);
	
	      return oItem.getText().match(new RegExp(sFilter, "i"));
	    });
	
	    this.attachSuggestionItemSelected(this.onSuggestionItemSelected);
	  },
	
	  onSuggestionItemSelected: function(oEvent) {
	    var sKey = oEvent.getParameters().selectedItem.getKey();
	    var aTokens = oEvent.getSource().getValueTokens() || [];
	    aTokens.push(sKey);
	    var sVal = aTokens.join(',');
	    oEvent.getSource().setValue(sVal);
	  },
	
	  _onsaparrowkey: function(oEvent, sDirection) {
	    var sVal = this.getValue();
	    Input.prototype._onsaparrowkey.call(this, oEvent, sDirection);
	    this.setValue(sVal);
	    this._$input.val(sVal);
	  },
	
	  renderer: {
	  }
	});
});