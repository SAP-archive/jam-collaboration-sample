sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/jam/samples/components/grouplist/StringHelper"
], function(Controller, StringHelper) {
	"use strict";

	return Controller.extend("sap.jam.samples.components.grouplist.controller.CreateGroup", {
		createGroup: function() {
			var self = this,
				bus = sap.ui.getCore().getEventBus(),
				sTemplateId = this.byId("Template").getSelectedKey(),
				sName = this.byId("Name").getValue(),
				sDescription = this.byId("Description").getValue(),
				sGroupType = this.byId("Permission").getSelectedKey(),
				sInviteList = this.getInviteList(),
				bActivate = this.byId("Activate").getSelected(),
				sExObj,
				oContext = this.getView().getBindingContext(),
				oModel = this.getView().getModel("JamOData");

			if (oContext && oContext.getPath().indexOf("ExternalObjects") > -1) {
				sExObj = oModel.getProperty("__metadata/uri", oContext);
			}

			var postBody = {
				Name: sName,
				Description: sDescription,
				IsActive: bActivate,
				GroupType: sGroupType
			};
			if (sTemplateId && sTemplateId !== "NO_TEMPLATE") {
				postBody.Template = {
					__metadata: {
						uri: sTemplateId
					}
				};
			}
			if (sExObj) {
				postBody.PrimaryExternalObject = {
					__metadata: {
						uri: sExObj
					}
				};
			}

			oModel.create("Groups", postBody, {
				success: function(oData) {
					if (sInviteList) {
						self.inviteMembers(oData.results.Id, sInviteList);
					} else {
						bus.publish("jam.widget.create_group", "success");
					}
				},
				error: function(oError) {
					self.showErrorMessage(oError);
					bus.publish("jam.widget.create_group", "createFailed");
				}
			});
		},

		inviteMembers: function(sId, sEmails) {
			var oModel = this.getView().getModel("JamOData"),
				self = this,
				bus = sap.ui.getCore().getEventBus();
			var postBody = {
				Id: self.escapeArgument(sId),
				Email: self.escapeArgument(sEmails)
			};

			oModel.create("Group_Invite", {}, {
				success: function() {
					bus.publish("jam.widget.create_group", "success");
				},
				error: function(oError) {
					self.showErrorMessage(oError);
					bus.publish("jam.widget.create_group", "inviteFailed");
				},
				urlParameters: postBody
			});
		},

		cancelPressed: function() {
			var bus = sap.ui.getCore().getEventBus();
			bus.publish("jam.widget.create_group", "cancel");
		},

		toggleInvite: function(oEvent) {
			var sValue = "",
				oViewData = this.getView().getViewData(),
				oInput = this.byId("InviteList"),
				bSelected = oEvent.getSource().getSelected();
			if (bSelected && oViewData && oViewData.inviteList) {
				sValue = oViewData.inviteList.join();
			}
			oInput.setValue(sValue);
			oInput.setVisible(bSelected);
			oInput.setShowSuggestion(bSelected);
		},

		showErrorMessage: function(oError) {
			var sMessages = StringHelper.parseErrorMessage(oError);
			sap.m.MessageToast.show(sMessages[0]);
		},

		escapeArgument: function(sArg) {
			return "'" + sArg + "'";
		},

		memberAutocomplete: function(oEvent) {
			var sTerm = oEvent.getParameter("suggestValue"),
				oInput = oEvent.getSource(),
				oModel = oInput.getModel("JamOData");

			var sQuery = sTerm ? sTerm.trim().split(new RegExp("\\s*,\\s*")).pop() : "";
			if (!sQuery || !oModel) {
				return;
			}

			oModel.read("/Members_Autocomplete", {
				urlParameters: {
					Query: this.escapeArgument(sQuery)
				},
				success: function(oData) {
					oInput.destroySuggestionItems();
					if (oData && oData.results) {
						oData.results.forEach(function(result) {
							oInput.addSuggestionItem(new sap.ui.core.Item({
								text: result.FullName + " <" + result.Email + ">",
								key: result.Email
							}));
						});
					}
				}
			});
		},

		getInviteList: function() {
			var inviteFields = this.getView().inviteFields;
			if (inviteFields && inviteFields.length > 0) {
				var invites = [];
				inviteFields.forEach(function(aField) {
					invites.push(aField.getValue());
				});
				return invites.join();
			} else {
				return this.byId("InviteList").getValue();
			}
		},
		
		nameChanged: function(oEvent) {
            var bEnabled = !!oEvent.getParameters().newValue;
            this.byId("CreateButton").setEnabled(bEnabled);
        },
        
        permissionsChanged: function(oEvent) {
        	var sKey = oEvent.getParameters().selectedItem.getKey();
            if(sKey === "public_internal") {
              this.byId("Activate").setSelected(false);
            } else {
              this.byId("Activate").setSelected(true);
            }
        }

	});

});