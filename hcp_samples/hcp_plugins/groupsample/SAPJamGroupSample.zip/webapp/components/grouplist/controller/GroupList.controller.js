sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/odata/ODataModel"
], function(Controller, DateFormat, ODataModel) {
	"use strict";

	return Controller.extend("sap.jam.samples.components.grouplist.controller.GroupList", {
		onInit: function() {
			this.getRouter().getRoute("groupList").attachPatternMatched(this.refreshList, this);

			var self = this;
			this.setModel(new ODataModel("/destinations/sapjam_developer", true), "JamOData");
			
			this.byId("_refreshBtn").attachPress(function() {
				self.refreshList();
			});
			
			var bus = sap.ui.getCore().getEventBus();
			bus.subscribe("jam.widget.create_group", "cancel", function(){self.closeDialog();}, this);
			bus.subscribe("jam.widget.create_group", "success", function(){self.closeDialog();}, this);
			bus.subscribe("jam.widget.create_group", "inviteFailed", function(){self.closeDialog();}, this);
		},
		
		onNavBack: function() {
		},
		
		refreshList: function() {
			this.getModel("JamOData").refresh();
		},

		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		getModel: function(sName) {
			return this.getView().getModel(sName) || this.getOwnerComponent().getModel(sName);
		},
		
		setModel: function(oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},
		
		typeIconFormatter: function (sType) {
			switch(sType) {
              case "private_internal":
                return "sap-icon://locked";
              case "private_external":
                return "sap-icon://visits";
              case "public_internal":
                return "sap-icon://globe";
              default:
                return "";
            }
		},
		
		createGroup: function() {
			var oView = new sap.ui.view({viewName: "sap.jam.samples.components.grouplist.view.CreateGroup", type: sap.ui.core.mvc.ViewType.XML});
			oView.setModel(this.getModel("JamOData"), "JamOData");
			oView.setModel(this.getModel("i18n"), "i18n");
			this.createGroupDialog = new sap.m.Dialog({
				content: [oView],
				showHeader: false,
				contentWidth: "35rem"
			});
			this.createGroupDialog.open();
		},
		
		closeDialog: function() {
			if(this.createGroupDialog) {
				this.createGroupDialog.close();
				this.createGroupDialog.destroy();
				this.createGroupDialog = null;
			}	
		}

	});

});